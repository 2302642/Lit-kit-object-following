/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
**/
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */
/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */
/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define send 0xc1ae
/* USER CODE END PD */
/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */
/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;
/* USER CODE BEGIN PV */
uint8_t version_receive[26];
uint8_t version_send[4] = {0xAE, 0xC1, 0x0e, 0x00},
		resolution_send[] = {0xAE, 0xC1, 0x0C, 0x01, 0x00},
		resolution_receive[10],
		brightness_send[] = {0xAE, 0xC1, 0x10, 0x01, 0x00},
		brightness_receive[10],
		blocks_send[] = {0xAE, 0xC1, 0x20, 0x02, 0x01, 0x01},
		blocks_receive[20];

uint8_t cs;
uint8_t p1[1];
uint8_t DirByte;
uint8_t Low_SpdByte = 0x25;
uint8_t High_SpdByte = 0x30;
uint16_t CAMERA_CENTER = 130;
uint16_t AREA_THRESHOLD = 150 * 180; // w * h
/* USER CODE END PV */
/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART3_UART_Init(void);

void getVersion(void);
void getResolution(void);
void setCameraBrightness(uint8_t brightness);
void getBlocks(uint8_t sigmap,uint8_t maxBlocks);

uint8_t Stop[4] 			= {0x7A, 0x0A, 0x30, 0x00}, //array with data for stop
		Forward[4] 			= {0x7A, 0x01, 0x30, 0x00}, //array with data for forward
		Reverse[4]	 		= {0x7A, 0x02, 0x30, 0x00}, //array with data for reverse
		Turn_left[4] 		= {0x7A, 0x03, 0x30, 0x00}, //array with data for turn left
		Turn_right[4] 		= {0x7A, 0x04, 0x30, 0x00}, //array with data for turn right
		Diagonal_FL[4] 		= {0x7A, 0x06, 0x30, 0x00}, //array with data for top left
		Diagonal_FR[4]	 	= {0x7A, 0x07, 0x30, 0x00}, //array with data for top right
		Diagonal_RL[4] 		= {0x7A, 0x09, 0x30, 0x00}, //array with data for bottom left
		Diagonal_RR[4]	 	= {0x7A, 0x08, 0x30, 0x00}, //array with data for bottom right
		Clockwise[4] 		= {0x7A, 0x10, 0x30, 0x00}, //array with data for clockwise
		Count_clockwise[4] 	= {0x7A, 0x11, 0x30, 0x00}, //array with data for counter clockwise
		Move_Left[4] 		= {0x7A, 0x12, 0x30, 0x00}, //array with data for side left
		Move_Right[4] 		= {0x7A, 0x13, 0x30, 0x00}; //array with data for side right
uint16_t object_present, x_combined, y_combined, width_combined, height_combined;
/* USER CODE BEGIN PFP */			/* USER CODE END PFP */
/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int _write(int file, char *ptr, int len) {	(void)file;		int DataIdx;	for (DataIdx = 0; DataIdx < len; DataIdx++){ ITM_SendChar(*ptr++); }	return len;	}
/* USER CODE END 0 */
/**
  * @brief  The application entry point.
  * @retval int
**/
uint8_t calculate_xor_checksum(uint8_t *data, uint32_t length) {									// checksum algorithm function using XOR. Takes in the pointer to the first element of the array and size of the array
	uint8_t checksum = 0; 																			// initialise the checksum to be zero
    for (uint32_t i = 0; i < length; i++){ checksum ^= data[i]; }									// runs through each element and does the XOR operation. Updates the value of checksum accordingly.
    return checksum; 																				// returns the value of the checksum
}

void getVersion(void){ 																				// Send control_command to get Version
	if (HAL_UART_Transmit(&huart3, version_send, sizeof(version_send), 10) != HAL_OK) {
		char error_msg[50];
		sprintf(error_msg, "Error transmitting in getVersion()\n");
		HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
		return;
	}
	if (HAL_UART_Receive(&huart3, version_receive, sizeof(version_receive), 10) != HAL_OK)	{		// Receive version response
		char error_msg[50];
		sprintf(error_msg, "Error receiving in getVersion()\n");
		HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
		return;
	}
}

void getResolution(){ 																				// Send control_command to get resolution
    if (HAL_UART_Transmit(&huart3, resolution_send, sizeof(resolution_send), 100) != HAL_OK) {
        char error_msg[50];
        sprintf(error_msg, "Error transmitting in getResolution()\n");
        HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
        return;
    } 																								// Receive resolution response
    if (HAL_UART_Receive(&huart3, resolution_receive, sizeof(resolution_receive), 100) != HAL_OK) {
        char error_msg[50];
        sprintf(error_msg, "Error receiving in getResolution()\n");
        HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
        return;
    }

    // Process the resolution_receive to extract the resolution
    uint16_t width = resolution_receive[6] + resolution_receive[7];
    uint16_t height = resolution_receive[8]+ resolution_receive[9];
    char resolution_info[50];// Print or use width and height as needed
    sprintf(resolution_info, "Resolution: %d x %d\n", width, height);	printf(resolution_info);
    HAL_UART_Transmit(&huart2, (uint8_t*)resolution_info, strlen(resolution_info), HAL_MAX_DELAY);
}

void setCameraBrightness(uint8_t brightness) {
    if (brightness >= 0 && brightness <= 255) { brightness_send[4] = brightness; }
    else {
    	char error_msg[50];
    	sprintf(error_msg, "Brightness value of %d is out of range\n", brightness);
    	printf(error_msg);
    	HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
    	return;
    }

    printf("Setting brightness to %d\n", brightness);
    // Send control_command to get resolution
    if (HAL_UART_Transmit(&huart3, brightness_send, sizeof(brightness_send), 100) != HAL_OK) {
    	char error_msg[50];
        sprintf(error_msg, "Error transmitting in setCameraBrightness()\n");
        printf("Error transmitting in setCameraBrightness()\n");
        HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
        return;
    }
    if (HAL_UART_Receive(&huart3, brightness_receive, sizeof(brightness_receive), 100) != HAL_OK) {
    	char error_msg[50];
    	sprintf(error_msg, "Error receiving in setCameraBrightness()\n");
    	printf("Error receiving in setCameraBrightness()\n");
    	HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
    	return;
    }
    else {
    	printf("Brightness set to %u\n", brightness);
    	return;
    }
}

void getBlocks(uint8_t sigmap,uint8_t maxBlocks){
	if(sigmap >=0 && sigmap <=255) { blocks_send[4] = sigmap; }
	else{
		char error_msg[50];
		sprintf(error_msg, "sigmap value of %d is out of range\n", sigmap);
		printf(error_msg);
		HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
		return;
	}

	if(maxBlocks >= 0 && maxBlocks <= 255) { blocks_send[5] = maxBlocks; }
	else{
		char error_msg[50];
		sprintf(error_msg, "maxBlocks value of %d is out of range\n", maxBlocks);
		printf(error_msg);
		HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
		return;
	}

	if (HAL_UART_Transmit(&huart3, blocks_send, sizeof(blocks_send), 100) != HAL_OK) {
		char error_msg[100];
	    sprintf(error_msg, "Error transmitting in getBlocks()\n");
	    HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
	    return;
	}

	if (HAL_UART_Receive(&huart3, blocks_receive, sizeof(blocks_receive), 100) != HAL_OK) {
		char error_msg[100];
		sprintf(error_msg, "Error receiving in getBlocks()\n");
	    HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
	    return;
	}
	//uint16_t colorCode = blocks_receive[6]+blocks_receive[7];
	//uint16_t x = blocks_receive[8]+blocks_receive[9];
	uint16_t x = blocks_receive[9] << 8 | blocks_receive[8];
	//uint16_t y = blocks_receive[10]+blocks_receive[11];
	uint16_t width = blocks_receive[12]+blocks_receive[13];
	uint16_t height = blocks_receive[14]+blocks_receive[15];
	//uint16_t angle = blocks_receive[16]+blocks_receive[17];
	//uint16_t index = blocks_receive[18];
/*
	if    ((x >= 142 && x <= 148)&&(width >=112 && width <=118 )&&(height >=152 && height <=158)) { printf("Stop\n"); 					}     	// Stop Condition

	else if(x >= 142 && x <= 148 && width < 112                 && height < 152                 ) { printf("Forward\n"); 				}       // Forward Condition
	else if(x >= 142 && x <= 148 && width > 118                 && height > 158                 ) { printf("Reverse\n"); 				}		// Reverse Condition

	else if(x < 142              &&(width >=152 && width <= 158 && height >=112 && height <=118)) { printf("Move Left\n"); 				}       // Left Condition
	else if(x > 148              &&(width >=152 && width <= 158 && height >=112 && height <=118)) { printf("Move Right\n"); 			}       // Right Condition

	else if(x < 142              && width < 152                 && height < 112                 ) { printf("Diagonal Left Forward\n"); }       // Diagonal Left Forward Condition
	else if(x < 142              && width > 158                 && height > 118                 ) { printf("Diagonal Left Reverse\n"); }       // Diagonal Left Reverse Condition
	else if(x > 148              && width < 152                 && height < 112                 ) { printf("Diagonal Right Forward\n");}       // Diagonal Right Forward Condition
	else if(x > 148              && width > 158                 && height > 118                 ) { printf("Diagonal Right Reverse\n");}       // Diagonal Right Reverse Condition
*//*
			if(x >= 142 && x <= 148){
				if    ((width >=110 && width <=120 )&&(height >=150 && height <=160)) { printf("Stop\n");						data = 0x00;}     	// Stop Condition
				else if(width < 110                 && height < 150                 ) { printf("Forward\n");					data = 0x01;}       // Forward Condition
				else if(width > 120                 && height > 160                 ) { printf("Reverse\n");					data = 0x02;}		// Reverse Condition
			}
			else if(x < 142){
				if 	  ((width >=110 && width <= 120 && height >=150 && height <=160)) { printf("Move Left\n");					data = 0x06;}       // Left Condition
				else if(width < 110                 && height < 150                 ) { printf("Diagonal Left Forward\n"); 		data = 0x08;}       // Diagonal Left Forward Condition
				else if(width > 120                 && height > 160                 ) { printf("Diagonal Left Reverse\n"); 		data = 0x10;}       // Diagonal Left Reverse Condition
			}
			else if(x > 148){
				if 	  ((width >=110 && width <= 120 && height >=150 && height <=160)) { printf("Move Right\n");					data = 0x05;}       // Right Condition
				else if(width < 110                 && height < 150                 ) { printf("Diagonal Right Forward\n");		data = 0x07;}       // Diagonal Right Forward Condition
				else if(width > 120                 && height > 160                 ) { printf("Diagonal Right Reverse\n");		data = 0x09;}       // Diagonal Right Reverse Condition
			}
	*//*
	int width_L = 90, width_R = 140, High_Speed=1;
	//test motion based on width only
	if(x >= 148 && x <= 168){
		if     (width >=width_L && width <=width_R 	) { printf("Stop\n");		control_command(Stop,0);	 		}     	// Stop Condition
		else if(width < width_L) { printf("Forward\n");
			control_command(Forward, High_Speed);       // Forward Condition
		}
		else if(width > width_R) { printf("Reverse\n");					control_command(Reverse, High_Speed);		}		// Reverse Condition
	}
	else if(x < 148){
		if 	   (width >=width_L && width <=width_R	) { printf("Move Left\n");	control_command(Move_Left, High_Speed);		}       // Left Condition
		else if(width < width_L) { printf("Diagonal Left Forward\n"); 	control_command(Diagonal_FL, High_Speed);	}       // Diagonal Left Forward Condition
		else if(width > width_R) { printf("Diagonal Left Reverse\n"); 	control_command(Diagonal_RL, High_Speed);	}       // Diagonal Left Reverse Condition
	}
	else if(x > 168){
		if 	   (width >=width_L && width <=width_R	) { printf("Move Right\n");	control_command(Move_Right, High_Speed);	}       // Right Condition
		else if(width < width_L) { printf("Diagonal Right Forward\n");	control_command(Diagonal_FR, High_Speed);	}       // Diagonal Right Forward Condition
		else if(width > width_R) { printf("Diagonal Right Reverse\n");	control_command(Diagonal_RR, High_Speed);	}       // Diagonal Right Reverse Condition
	}
	else{control_command(Stop);}
	//char msg[100];
	//sprintf(msg,"Color Code: %d\n X: %d\n Y: %d\n Width: %d\n Height: %d\n Angle: %d\n Index: %d\n",colorCode,x,y,width,height,angle,index);
	//printf(msg);
	return;
	  */
	  int left = 0;
	  int right = 0;
	  int front = 0;
	  int back = 0;
	  int halt = 0;
	  int High_Speed = 0;

	  int Dwidth_R = 70;
	  int Dwidth_L = Dwidth_R+ 30;		//lower is more sensetive,

	  if((x>=138 && x<=178) && (width>=Dwidth_R && width<=Dwidth_L)){ left = 0; right = 0; front = 0; back = 0; halt = 1;}
	  else if(x<148){ left = 1; right = 0; halt = 0;}
	  else if(x>168){ left = 0; right = 1; halt = 0;}

	  if(width<Dwidth_R /*&& height<140*/){
		 front = 1; back = 0; halt = 0;
	    if(width<(Dwidth_R-20) /*&& height<100*/){High_Speed = 1;}
	    else{High_Speed = 0;}
	  }
	  else if(width>Dwidth_L /*&& height>160*/){
		back = 1; front = 0; halt = 0;
	    if(width>(Dwidth_L+20) /*&& height>180*/){High_Speed = 1;}
	    else{High_Speed = 0;}
	  }

	  if(front == 1){
		  if	 (right == 1)	{ printf("Diagonal Forward Right\n");	control_command(Diagonal_FR, High_Speed);	}
		  else if(left == 1)	{ printf("Diagonal Forward Left\n");	control_command(Diagonal_FL, High_Speed);	}
		  else					{ printf("Forward\n"); 					control_command(Forward, 	 High_Speed); 	}
	  }
	  else if(back == 1){
		  if	 (right == 1)	{ printf("Diagonal Reverse Right\n"); 	control_command(Diagonal_RR, High_Speed); 	}
		  else if(left == 1)	{ printf("Diagonal Reverse Left\n"); 	control_command(Diagonal_RL, High_Speed); 	}
		  else 					{ printf("Reverse\n"); 					control_command(Reverse, 	 High_Speed); 	}
	  }
	  else{
		  if	 (right == 1)	{ printf("Move right\n"); 				control_command(Move_Right, High_Speed); 	}
	      else if(left == 1)	{ printf("Move left\n"); 				control_command(Move_Left, 	High_Speed); 	}
	      else					{ printf("stop\n"); 					control_command(Stop, 0);					}
	  }
	return;
}

//void transmitData(uint8_t* data, int delay){ HAL_UART_Transmit(&huart1, data, sizeof(data), delay); }
void control_command(uint8_t arr[], int High_Speed) {
	if(High_Speed == 1)	{arr[2] = High_SpdByte;}
	else				{ arr[2] = Low_SpdByte;}
	arr[3] = arr[0] ^ arr[1] ^ arr[2];	//printf("CheckSum %u\n",arr[3]);
	do {
		HAL_UART_Transmit(&huart1, arr, sizeof(arr), 100);
		HAL_UART_Receive(&huart1, p1, sizeof(p1), 100);
	} while (p1[0] != arr[3]);
}

int main(void)
{
	/* USER CODE BEGIN 1 */					/* USER CODE END 1 */
	/* MCU Configuration--------------------------------------------------------*/
	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
 	HAL_Init();
	/* USER CODE BEGIN Init */				/* USER CODE END Init */
	/* Configure the system clock */
	SystemClock_Config();
	/* USER CODE BEGIN SysInit */			/* USER CODE END SysInit */
	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_USART1_UART_Init();
	MX_USART2_UART_Init();
	MX_USART3_UART_Init();
	/* USER CODE BEGIN 2 */
	getVersion();
	getResolution();
	setCameraBrightness(50);

	printf("Version Byte 0 = %d\n", version_receive[0]);
	printf("Version Byte 1 = %d\n", version_receive[1]);
	fflush(stdout);
	/* USER CODE END 2 */
	/* Infinite loop */
	/* USER CODE BEGIN WHILE */

	while(1){

		getBlocks(1, 255);
		//uint8_t datxData 0x02;
		if(blocks_receive[3] == 0){
			printf("No Target Found!\n");
			control_command(Stop,0);
		}
	}
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void){
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  // Initializes the RCC Oscillators according to the specified parametersn in the RCC_OscInitTypeDef structure.
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  // Initializes the CPU, AHB and APB buses clocks
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) { Error_Handler(); }
}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void){
  /* USER CODE BEGIN USART1_Init 0 */			/* USER CODE END USART1_Init 0 */
  /* USER CODE BEGIN USART1_Init 1 */			/* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK) { Error_Handler(); }
  /* USER CODE BEGIN USART1_Init 2 */			/* USER CODE END USART1_Init 2 */
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void) {
  /* USER CODE BEGIN USART2_Init 0 */			/* USER CODE END USART2_Init 0 */
  /* USER CODE BEGIN USART2_Init 1 */		    /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK){	Error_Handler();	}
  /* USER CODE BEGIN USART2_Init 2 */  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void) {
  /* USER CODE BEGIN USART3_Init 0 */			/* USER CODE END USART3_Init 0 */
  /* USER CODE BEGIN USART3_Init 1 */			/* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK) { Error_Handler(); }
  /* USER CODE BEGIN USART3_Init 2 */			 /* USER CODE END USART3_Init 2 */
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void) {
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */			/* USER CODE END MX_GPIO_Init_1 */

 /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */			/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */			/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void) {
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1){}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line) {
  /* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
       ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
